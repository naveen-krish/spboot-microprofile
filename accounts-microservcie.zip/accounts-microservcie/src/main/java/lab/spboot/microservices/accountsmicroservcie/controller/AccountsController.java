package lab.spboot.microservices.accountsmicroservcie.controller;

import lab.spboot.microservices.accountsmicroservcie.domain.CustomerInfo;
import lab.spboot.microservices.accountsmicroservcie.service.AccountsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("accounts")
public class AccountsController {
    Logger logger = LoggerFactory.getLogger(AccountsController.class);
    @Autowired
    private AccountsService accountsService;

    @PostMapping("/createAccount")
    public Map createAccount(@RequestBody CustomerInfo customerInfo){
        logger.info(" << Accounts Controller >> ");
        return accountsService.addAccount(customerInfo.getId(), customerInfo.getAccount());
    }

    @PostMapping("/deleteAccount")
    public Map deleteAccount(@RequestBody CustomerInfo customerInfo){
        return accountsService.removeAccount(customerInfo.getId());
    }
}
