package lab.spboot.microservices.accountsmicroservcie.service;

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Service
public class AccountsService {
    private Map<Integer, String> accountsMap;
    @PostConstruct
    private void init() {
        this.accountsMap = new HashMap<Integer, String>();
//        accountsMap.put(1,"001");
//        accountsMap.put(2,"002");
    }

    public Map addAccount(int customerId,String account){
        accountsMap.put(customerId,account);
        return accountsMap;
    }

    public Map removeAccount(int customerId){
        accountsMap.remove(customerId);
        return accountsMap;
    }
}
