package lab.spboot.microservices.accountsmicroservcie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountsMicroservcieApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountsMicroservcieApplication.class, args);
	}

}
