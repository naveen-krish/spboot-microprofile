package lab.spboot.microservices.accountsmicroservcie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountsMicroservcieApplicationTests {

	@Test
	void contextLoads() {
	}

}
