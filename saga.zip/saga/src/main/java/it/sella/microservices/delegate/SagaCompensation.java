package it.sella.microservices.delegate;

import org.camunda.bpm.engine.delegate.JavaDelegate;

public interface SagaCompensation extends JavaDelegate {
}
