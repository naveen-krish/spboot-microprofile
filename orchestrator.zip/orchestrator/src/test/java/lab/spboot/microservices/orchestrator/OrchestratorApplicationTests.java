package lab.spboot.microservices.orchestrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrchestratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
