package lab.spboot.microservices.orchestrator.saga.enums;

public enum CustomerStatus {

    CUSTOMER_CREATED,
    CUSTOMER_CANCELLED,
    CUSTOMER_CREATE_COMPLETED

}