package lab.spboot.microservices.orchestrator.saga.enums;

public enum  InventoryStatus {
    AVAILABLE,
    UNAVAILABLE;
}
