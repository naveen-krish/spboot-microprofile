package lab.spboot.microservices.orchestrator.saga;

public enum WorkflowStepStatus {
    PENDING,
    COMPLETE,
    FAILED;
}