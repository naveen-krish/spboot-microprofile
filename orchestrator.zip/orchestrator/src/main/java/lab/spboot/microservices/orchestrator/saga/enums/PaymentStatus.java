package lab.spboot.microservices.orchestrator.saga.enums;

public enum  PaymentStatus {
    PAYMENT_APPROVED,
    PAYMENT_REJECTED;
}
